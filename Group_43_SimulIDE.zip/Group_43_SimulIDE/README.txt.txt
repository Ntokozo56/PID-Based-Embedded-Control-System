Group: 43
SimulIDE Version: 1.1.0


SimulIDE_1.1.0
How to Run Simulation:
1. Open SimulIDE.
2. Open the file SR1_Win64/data/Final_Project_Layout.sim1
3. Ensure all required libraries are installed.
4. Start the simulation.

Arduino Build:
1. Open Arduino\Final.Project.ino in Arduino IDE
2. Make sure the required libraries are installed
3. Upload to the Arduino board

Library Differences:
- Simulation: <Wire.h> 
              <LiquidCrystal_AIP31068_I2C.h>

- Practical:  <Wire.h> 
              <LiquidCrystal_I2C.h>
