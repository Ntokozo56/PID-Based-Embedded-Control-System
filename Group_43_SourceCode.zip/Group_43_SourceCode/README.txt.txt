Group: 43
SimulIDE Version: 1.1.0

BOARDS USED

Simulation Environment:
- Board: Arduino UNO Simulated in SimulIDE
- Libraries:
    - Wire.h Built-in
    - LiquidCrystal_AIP31068_I2C.h Simulation LCD library for AIP31068 controller

Practical Environment:
- Board: Arduino UNO Physical hardware
- Libraries:
    - Wire.h Built-in
    - LiquidCrystal_I2C.h Standard I2C LCD library

LIBRARY DIFFERENCES
Simulation:
- <Wire.h>
- <LiquidCrystal_AIP31068_I2C.h>

Practical:
- <Wire.h>
- <LiquidCrystal_I2C.h>

HOW TO RUN SIMULATION

1. Open SimulIDE 
2. Go to File → Open Circuit.
3. Load the project file located at:
   file SR1_Win64/data/Final_Project_Layout.sim1
4. Verify that the simulation board is set to Arduino UNO.
5. Click the green **Play** button in SimulIDE to start the simulation.

HOW TO BUILD

1. Open the Arduino IDE Version 2.0
2. Open the file:
   Arduino\Final.Project.ino in Arduino IDE
3. Connect your Arduino UNO via USB.
4. Select the board and port:
   - Tools → Board → Arduino UNO
   - Tools → Port →  COM6
5. Ensure the required libraries are installed:
   - Wire (included with Arduino IDE)
   - LiquidCrystal_I2C (Install via Library Manager)
6. Click **Verify** to compile the sketch.
7. Click **Upload** to flash the program to your Arduino.

